//# sourceMappingURL=homeController.js.map
(function(){var a=function(a){};a.$inject=["homeService"];angular.module("bootdemo.home").controller("HomeController",a)})();